npm init -y

npm install express

package.lock json  


insert()
insertone()
insertMany()

db.users.insert([{ "name" : "anvita", "age":23, "place":"pune"},
{ "name" : "sakshi", "age":25, "place":"agra"},
{ "name" : "ram", "age":20, "place":"mum"}]);

db.users.find()

db.users.find({"place":"pune"})

db.users.remove({"place":"mum"})
db.users.update(
    {"place":"katraj"
    },
    {
    $set : {
         "name":"ram", "age":20
         }
})

npm i mongoose

npm install mysql