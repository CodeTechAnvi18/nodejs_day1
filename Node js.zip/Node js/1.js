
console.log("hello");
var xmlhttp = new XMLHttpRequest();
 console.log(xmlhttp);
 